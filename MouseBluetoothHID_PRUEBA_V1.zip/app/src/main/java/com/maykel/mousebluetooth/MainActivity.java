package com.maykel.mousebluetooth;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothHidDevice;
import android.bluetooth.BluetoothHidDeviceAppQosSettings;
import android.bluetooth.BluetoothHidDeviceAppSdpSettings;
import android.bluetooth.BluetoothManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final int REQ_BT = 100;
    private BluetoothAdapter adapter;
    private BluetoothHidDevice hid;
    private BluetoothDevice target;
    private boolean registered = false;
    private TextView status;
    private Spinner devicesSpinner;
    private Button connectBtn, disconnectBtn;
    private final List<BluetoothDevice> bonded = new ArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());

    // Standard 3-button mouse + X/Y/Wheel HID report descriptor.
    private static final byte[] MOUSE_DESCRIPTOR = new byte[] {
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x02,             // Usage (Mouse)
        (byte)0xA1, 0x01,       // Collection (Application)
        0x09, 0x01,             // Usage (Pointer)
        (byte)0xA1, 0x00,       // Collection (Physical)
        0x05, 0x09,             // Usage Page (Buttons)
        0x19, 0x01,             // Usage Minimum (1)
        0x29, 0x03,             // Usage Maximum (3)
        0x15, 0x00,             // Logical Minimum (0)
        0x25, 0x01,             // Logical Maximum (1)
        (byte)0x95, 0x03,       // Report Count (3)
        (byte)0x75, 0x01,       // Report Size (1)
        (byte)0x81, 0x02,       // Input (Data,Var,Abs)
        (byte)0x95, 0x01,       // Report Count (1)
        (byte)0x75, 0x05,       // Report Size (5)
        (byte)0x81, 0x01,       // Input (Constant)
        0x05, 0x01,             // Usage Page (Generic Desktop)
        0x09, 0x30,             // Usage (X)
        0x09, 0x31,             // Usage (Y)
        0x09, 0x38,             // Usage (Wheel)
        0x15, (byte)0x81,       // Logical Minimum (-127)
        0x25, 0x7F,             // Logical Maximum (127)
        0x75, 0x08,             // Report Size (8)
        (byte)0x95, 0x03,       // Report Count (3)
        (byte)0x81, 0x06,       // Input (Data,Var,Rel)
        (byte)0xC0,             // End Physical
        (byte)0xC0              // End Application
    };

    private final BluetoothHidDevice.Callback hidCallback = new BluetoothHidDevice.Callback() {
        @Override public void onAppStatusChanged(BluetoothDevice pluggedDevice, boolean registeredNow) {
            registered = registeredNow;
            main.post(() -> {
                if (registeredNow) setStatus("HID registrado. Selecciona la tableta y pulsa CONECTAR.");
                else setStatus("HID no registrado.");
                updateButtons();
            });
        }

        @Override public void onConnectionStateChanged(BluetoothDevice device, int state) {
            main.post(() -> {
                if (state == BluetoothProfileCompat.STATE_CONNECTED) {
                    target = device;
                    setStatus("🟢 CONECTADO: " + safeName(device));
                } else if (state == BluetoothProfileCompat.STATE_DISCONNECTED) {
                    setStatus("🔵 HID desconectado.");
                } else {
                    setStatus("Estado Bluetooth HID: " + state);
                }
                updateButtons();
            });
        }
    };

    // Constants avoid depending on hidden/internal APIs.
    static class BluetoothProfileCompat {
        static final int STATE_CONNECTED = 2;
        static final int STATE_DISCONNECTED = 0;
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
        requestBluetoothPermissions();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);

        TextView title = new TextView(this);
        title.setText("🖱️  Mouse Bluetooth — PRUEBA");
        title.setTextSize(24);
        title.setPadding(0,0,0,16);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(17);
        status.setText("Comprobando Bluetooth HID...");
        status.setPadding(0,0,0,16);
        root.addView(status);

        TextView info = new TextView(this);
        info.setText("1. Vincula la tableta desde Ajustes > Bluetooth.\n" +
                     "2. Selecciona la tableta aquí.\n" +
                     "3. Pulsa CONECTAR.\n" +
                     "4. Mueve el dedo sobre el área azul.");
        info.setTextSize(15);
        info.setPadding(0,0,0,12);
        root.addView(info);

        devicesSpinner = new Spinner(this);
        root.addView(devicesSpinner, new LinearLayout.LayoutParams(-1, 56));

        Button refresh = new Button(this);
        refresh.setText("Actualizar dispositivos vinculados");
        refresh.setOnClickListener(v -> loadBondedDevices());
        root.addView(refresh);

        connectBtn = new Button(this);
        connectBtn.setText("CONECTAR");
        connectBtn.setOnClickListener(v -> connectSelected());
        root.addView(connectBtn);

        disconnectBtn = new Button(this);
        disconnectBtn.setText("DESCONECTAR");
        disconnectBtn.setOnClickListener(v -> disconnect());
        root.addView(disconnectBtn);

        FrameLayout pad = new FrameLayout(this);
        TextView padText = new TextView(this);
        padText.setText("ÁREA TOUCHPAD\n\nMueve el dedo para mover el puntero\nToque = clic izquierdo");
        padText.setGravity(17);
        padText.setTextSize(18);
        padText.setTextColor(0xFFFFFFFF);
        padText.setBackgroundColor(0xFF1976D2);
        pad.addView(padText, new FrameLayout.LayoutParams(-1,-1));

        pad.setOnTouchListener(new View.OnTouchListener() {
            float lastX, lastY;
            boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
                    lastX=e.getX(); lastY=e.getY(); moved=false; return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_MOVE) {
                    float dx=e.getX()-lastX, dy=e.getY()-lastY;
                    lastX=e.getX(); lastY=e.getY();
                    if (Math.abs(dx)>0 || Math.abs(dy)>0) moved=true;
                    sendMove(Math.round(dx*1.5f), Math.round(dy*1.5f), 0);
                    return true;
                }
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    if (!moved) {
                        sendButton(1, true);
                        sendButton(1, false);
                    }
                    return true;
                }
                return true;
            }
        });
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,0,1);
        pp.topMargin=16;
        root.addView(pad, pp);

        setContentView(root);
    }

    private void requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            }, REQ_BT);
        } else initBluetooth();
    }

    @Override public void onRequestPermissionsResult(int r, String[] p, int[] g) {
        super.onRequestPermissionsResult(r,p,g);
        if (r==REQ_BT) initBluetooth();
    }

    private void initBluetooth() {
        BluetoothManager bm=(BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
        adapter=bm.getAdapter();
        if (adapter==null) { setStatus("❌ Este teléfono no tiene Bluetooth."); return; }
        if (!adapter.isEnabled()) {
            setStatus("⚠️ Activa Bluetooth desde Ajustes.");
            return;
        }
        setStatus("Bluetooth activo. Comprobando perfil HID...");
        adapter.getProfileProxy(this, new BluetoothProfileProxyListener(),
                android.bluetooth.BluetoothProfile.HID_DEVICE);
        loadBondedDevices();
    }

    private class BluetoothProfileProxyListener implements android.bluetooth.BluetoothProfile.ServiceListener {
        @Override public void onServiceConnected(int profile, android.bluetooth.BluetoothProfile proxy) {
            hid=(BluetoothHidDevice)proxy;
            BluetoothHidDeviceAppSdpSettings sdp =
                new BluetoothHidDeviceAppSdpSettings(
                    "Mouse Bluetooth", "Android Bluetooth Mouse",
                    "Maykel", MOUSE_DESCRIPTOR);
            hid.registerApp(sdp, null, null, Executors.newSingleThreadExecutor(), hidCallback);
            setStatus("Perfil HID disponible. Registrando mouse...");
        }
        @Override public void onServiceDisconnected(int profile) {
            hid=null; registered=false; setStatus("Perfil HID desconectado del sistema.");
        }
    }

    private void loadBondedDevices() {
        if (adapter==null) return;
        try {
            bonded.clear();
            bonded.addAll(adapter.getBondedDevices());
            ArrayList<String> names=new ArrayList<>();
            for (BluetoothDevice d: bonded) names.add(safeName(d));
            if(names.isEmpty()) names.add("No hay dispositivos vinculados");
            devicesSpinner.setAdapter(new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_dropdown_item, names));
        } catch (SecurityException e) {
            setStatus("Permiso Bluetooth no concedido.");
        }
    }

    private String safeName(BluetoothDevice d) {
        try { return d.getName()!=null ? d.getName() : d.getAddress(); }
        catch(Exception e){ return "Dispositivo Bluetooth"; }
    }

    private void connectSelected() {
        if(hid==null || !registered) { setStatus("❌ HID todavía no está registrado."); return; }
        if(bonded.isEmpty()) { setStatus("Vincula primero la tableta desde Ajustes Bluetooth."); return; }
        int pos=devicesSpinner.getSelectedItemPosition();
        if(pos<0 || pos>=bonded.size()) return;
        target=bonded.get(pos);
        try {
            hid.connect(target);
            setStatus("Conectando con " + safeName(target) + "...");
        } catch(SecurityException e) {
            setStatus("Permiso Bluetooth insuficiente.");
        }
    }

    private void disconnect() {
        if(hid!=null && target!=null) {
            try { hid.disconnect(target); } catch(Exception ignored) {}
        }
        target=null;
        setStatus("🔵 Desconectado.");
        updateButtons();
    }

    private boolean ready() {
        return hid!=null && target!=null;
    }

    private void sendMove(int dx, int dy, int wheel) {
        if(!ready()) return;
        dx=Math.max(-127,Math.min(127,dx));
        dy=Math.max(-127,Math.min(127,dy));
        wheel=Math.max(-127,Math.min(127,wheel));
        try { hid.sendReport(target, 0, new byte[]{0,(byte)dx,(byte)dy,(byte)wheel}); }
        catch(Exception ignored) {}
    }

    private void sendButton(int button, boolean down) {
        if(!ready()) return;
        int mask=down ? (1<<(button-1)) : 0;
        try { hid.sendReport(target, 0, new byte[]{(byte)mask,0,0,0}); }
        catch(Exception ignored) {}
    }

    private void setStatus(String s) {
        if(status!=null) status.setText(s);
    }

    private void updateButtons() {
        boolean r=hid!=null && registered;
        if(connectBtn!=null) connectBtn.setEnabled(r);
        if(disconnectBtn!=null) disconnectBtn.setEnabled(target!=null);
    }

    @Override protected void onDestroy() {
        if(hid!=null) {
            try { hid.unregisterApp(); } catch(Exception ignored) {}
            try { adapter.closeProfileProxy(android.bluetooth.BluetoothProfile.HID_DEVICE, hid); } catch(Exception ignored) {}
        }
        super.onDestroy();
    }
}
