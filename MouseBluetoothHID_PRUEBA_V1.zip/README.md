# Mouse Bluetooth HID — APK de prueba

Primera versión del proyecto para probar si el Galaxy A03 Core puede funcionar
como mouse Bluetooth HID frente a una tableta Android 13.

## Prueba

1. Vincular el teléfono y la tableta desde Ajustes > Bluetooth.
2. Instalar la APK en el teléfono.
3. Abrir "Mouse Bluetooth".
4. Conceder el permiso "Dispositivos cercanos".
5. Seleccionar la tableta en la lista.
6. Pulsar CONECTAR.
7. Mover el dedo en el área azul.
8. Probar un toque para clic izquierdo.

La APK también informa si el perfil Bluetooth HID Device no está disponible
en el teléfono.
